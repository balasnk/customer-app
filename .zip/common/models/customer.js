module.exports = function(Customer) {

};
